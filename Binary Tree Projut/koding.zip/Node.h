#include <iostream>
#include <string>

using namespace std;

class Node
{

};

void bacaFile();